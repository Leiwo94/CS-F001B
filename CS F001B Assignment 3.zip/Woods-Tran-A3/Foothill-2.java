//Assignment 3 Cellular Automata by Jennifer Tran and Lei Woods
import java.util.Arrays;
import java.util.Scanner;


public class Foothill
{
   public static void main(String[] args)
   {
      int rule, k;
      String strUserIn;
      
      Scanner inputStream = new Scanner(System.in);
      Automaton aut;

      // get rule from user
      do
      {
         System.out.print("Enter Rule ("  
               + Automaton.MIN_RULE + " - " +  Automaton.MAX_RULE + "): ");
         // get the answer in the form of a string:
         strUserIn = inputStream.nextLine();
         // and convert it to a number so we can compute:
         rule = Integer.parseInt(strUserIn);

      } while (rule < Automaton.MIN_RULE || rule > Automaton.MAX_RULE);

      // create automaton with this rule and single central dot
      aut = new Automaton(rule);

      // now show it
      System.out.println("   start");
      for (k = 0; k < 50; k++)
      {
         System.out.println( aut.toStringCurrentGen() );
         aut.propagateNewGeneration();
      }
      inputStream.close();
      System.out.println("   end");
   }
}

class Automaton
{
   // class constants
   public final static int RULES_SIZE = 8;
   public final static int BITS_IN_RULE_SIZE = (int)(Math.log(RULES_SIZE) / Math.log(2));
   public final static int MIN_DISPLAY_WIDTH = 1;
   public final static int MAX_DISPLAY_WIDTH = 121;
   public final static int DFLT_DISPLAY_WIDTH = 79;
   public final static int MIN_RULE = 0;
   public final static int MAX_RULE = (int)Math.pow(2,RULES_SIZE) - 1; // 255
   public final static int DFLT_RULE = 1;
   public final static String ON_STR = "*";
   public final static String OFF_STR = " ";
   
   // private members
   private boolean rules[];   // allocate rule[8] in constructor!
   private String thisGen;   // same here
   String extremeBit; // bit, "*" or " ", implied everywhere "outside"
   int displayWidth;  // an odd number so it can be perfectly centered
   
   
   // public constructor 
   public Automaton(int newRule)
   {
      rules = new boolean[RULES_SIZE];
      displayWidth = DFLT_DISPLAY_WIDTH;
      if ( !setRule(newRule))
         setRule(0);
      resetFirstGen();
   }
   
   //boolean for rule 
   public boolean[] getRule()
   {
      return rules;
   }
   
   // resets the first gen string 
   public void resetFirstGen()
   {
      extremeBit = OFF_STR; 
      thisGen = ON_STR;  
      int excesslength = (displayWidth - thisGen.length())/2;
      for (int i =0; i < excesslength; i++ )
      {
         thisGen = extremeBit + thisGen + extremeBit;  
      }
   }
   
   // looks at rule and converts it to binary
   public boolean setRule(int newRule)
   {
      
      if (newRule < MIN_RULE || newRule > MAX_RULE)
         return false;
      for(int i = RULES_SIZE -1; i >= 0; i--)
      {
         if( newRule >=  Math.pow(2, i))
         {
            rules[RULES_SIZE-1-i] = true;
            newRule -= Math.pow(2, i);
         }
         else
         {
            rules[RULES_SIZE-1-i] = false;
         }

      }
      return true;
   }
   
   // checks the width from user and sets it with given width 
   public boolean setDisplayWidth(int width)
   {
      if (width < MIN_DISPLAY_WIDTH || width > MAX_DISPLAY_WIDTH)
         return false;
      if (width % 2 == 0)
         return false;
      displayWidth = width;
      return true;
   }
   
   // strings the generation, cuts the excess and gives the it extra if too little
   public String toStringCurrentGen()
   {
      String copGenString = thisGen;
      int excesslength;
      //Amount needed to pad either side of the return string
      int genLength = thisGen.length();
      String returnString;
      if (genLength < displayWidth)
      {
         excesslength = (displayWidth - genLength)/2;
         for (int i =0; i < excesslength; i++ )
         {
            copGenString = extremeBit + copGenString + extremeBit;  
         }
      }
      else if (genLength > displayWidth)
      {
         excesslength =(genLength - displayWidth)/2;
         copGenString = copGenString.substring(excesslength, genLength - excesslength);
      }
      return copGenString;      
   }
   
   //looks at rules and the binary of thisGen and turns it into an integer to compare
   public void propagateNewGeneration()
   {
      thisGen = extremeBit+extremeBit+thisGen+extremeBit+extremeBit;
      String nextGen = "";
      for(int i = 1; i< thisGen.length()-1; i++)
      {
         boolean Storage1 = thisGen.charAt(i-1) == ON_STR.charAt(0);
         boolean Storage2 = thisGen.charAt(i) == ON_STR.charAt(0);
         boolean Storage3 = thisGen.charAt(i+1) == ON_STR.charAt(0);
         int Total = 0;
         if(Storage1)
         {
            Total += 4;
         }
         if(Storage2)
         {
            Total += 2;
         }
         if(Storage3)
         {
            Total += 1;
         }
         if(rules[(RULES_SIZE -1)-Total])
         {
            nextGen += ON_STR;
         }
         else
         {
            nextGen += OFF_STR;
         }       
      }
      thisGen = nextGen;
   }
   

}