
import java.util.logging.Logger;

import javax.swing.JOptionPane;

//import javax.annotation.Generated;

import org.junit.After;
import org.junit.AfterClass;
import org.junit.Assert;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Test;
import org.junit.tools.configuration.base.MethodRef;

import mockit.Deencapsulation;

//@Generated(value = "org.junit-tools-1.0.6")
public class AutomatonTest
{

//	@Generated(value = "org.junit-tools-1.0.6")
    private Logger logger = Logger.getLogger(AutomatonTest.class.toString());
    private static final int DEFAULT_DISPLAY_WIDTH = 79;

    @Before
    public void setUp() throws Exception
    {

    }

    @BeforeClass
    public static void setUpBeforeClass() throws Exception
    {

    }

    @After
    public void tearDown() throws Exception
    {

    }

    @AfterClass
    public static void tearDownAfterClass() throws Exception
    {

    }

    private Automaton createTestSubject()
    {
        return new Automaton(0);
    }

    @MethodRef(name = "resetFirstGen", signature = "()V")
    @Test
    public void testResetFirstGen() throws Exception
    {
        Automaton testSubject;

        // default test
        testSubject = createTestSubject();
        testSubject.resetFirstGen();

        String result = testSubject.toStringCurrentGen();

        Assert.assertEquals("                                       *                                       ", result);
    }

    @MethodRef(name = "setRule", signature = "(I)Z")
    @Test
    public void testSetRule() throws Exception
    {
        Automaton testSubject;
        int newRule = 0;
        boolean result;

        // test 1
        testSubject = createTestSubject();
        newRule = 0;
        result = testSubject.setRule(newRule);
        Assert.assertEquals(true, result);

        // test 2
        testSubject = createTestSubject();
        newRule = -1;
        result = testSubject.setRule(newRule);
        Assert.assertEquals(false, result);

        // test 3
        testSubject = createTestSubject();
        newRule = 1;
        result = testSubject.setRule(newRule);
        Assert.assertEquals(true, result);

        // test 4
        testSubject = createTestSubject();
        newRule = 255;
        result = testSubject.setRule(newRule);
        Assert.assertEquals(true, result);

        // test 5
        testSubject = createTestSubject();
        newRule = 254;
        result = testSubject.setRule(newRule);
        Assert.assertEquals(true, result);

        // test 6
        testSubject = createTestSubject();
        newRule = 256;
        result = testSubject.setRule(newRule);
        Assert.assertEquals(false, result);
    }

    @MethodRef(name = "setDisplayWidth", signature = "(I)Z")
    @Test
    public void testSetDisplayWidth() throws Exception
    {
        Automaton testSubject;
        int width = 0;
        boolean result;

        // test 1
        testSubject = createTestSubject();
        width = 1;
        result = testSubject.setDisplayWidth(width);
        Assert.assertEquals(true, result);
       

        // test 2
        testSubject = createTestSubject();
        width = 0;
        result = testSubject.setDisplayWidth(width);
        Assert.assertEquals("A width of zero isn't useful", false, result);

        // test 3
        testSubject = createTestSubject();
        width = 2;
        result = testSubject.setDisplayWidth(width);
        Assert.assertEquals("Even widths should NOT be allowed", false, result);

        // test 4
        testSubject = createTestSubject();
        width = -1;
        result = testSubject.setDisplayWidth(width);
        Assert.assertEquals("Negative widths aren't useful", false, result);

        // test 5
        testSubject = createTestSubject();
        width = Automaton.MAX_DISPLAY_WIDTH;
        result = testSubject.setDisplayWidth(width);
        Assert.assertEquals(true, result);

        // test 6
        testSubject = createTestSubject();
        width = Automaton.MAX_DISPLAY_WIDTH + 1;
        result = testSubject.setDisplayWidth(width);
        Assert.assertEquals("Widths above MAX_DISPLAY_WIDTH are not allowed", false, result);
    }

    @MethodRef(name = "toStringCurrentGen", signature = "()QString;")
    @Test
    public void testToStringCurrentGen() throws Exception
    {
        Automaton testSubject;
        String result;

        // default test
        testSubject = createTestSubject();
        result = testSubject.toStringCurrentGen();

        Assert.assertEquals("                                       *                                       ", result);
    }

    @MethodRef(name = "propagateNewGeneration", signature = "()V")
    @Test
    public void testPropagateNewGeneration() throws Exception
    {
        Automaton testSubject;

        // default test
        testSubject = createTestSubject();
        String result = testSubject.toStringCurrentGen();
        Assert.assertEquals("                                       *                                       ", result);
        testSubject.propagateNewGeneration();
        result = testSubject.toStringCurrentGen();

        Assert.assertEquals("                                                                               ", result);
    }

    @Test
    public void testDisplayWidth() throws Exception
    {
        // Default displayWidth test
        Automaton testSubject = createTestSubject();
        int displayWidth;
        try
        {
            displayWidth = Deencapsulation.getField(testSubject, "displayWidth");
            Assert.assertNotNull("displayWidth should have been set in the constructor", displayWidth);
            Assert.assertTrue("displayWidth:" + displayWidth + " should be greater or equal to 3", displayWidth >= 3);
            Assert.assertTrue("displayWidth:" + displayWidth + " should be 79 by default", displayWidth == 79);
        } catch (IllegalArgumentException e)
        {
            e.printStackTrace();
            Assert.fail(e.getLocalizedMessage()
                    + "\ndisplayWidth should have been declared and then set in the constructor");
        }
    }

    @Test
    public void testAutomaton() throws Exception
    {
        Automaton testSubject = null;
        // Constructor tests
        try
        {
            testSubject = new Automaton(1);
        } catch (NullPointerException e)
        {
            e.printStackTrace();
            Assert.fail(e.getLocalizedMessage()
                    + "\nYour group should have allocated a rules array in the constructor like this:\n"
                    + "rules = new boolean[8];");
        }
        testSubject.setDisplayWidth(DEFAULT_DISPLAY_WIDTH);
        testSubject.propagateNewGeneration();
        String result = testSubject.toStringCurrentGen();
        Assert.assertEquals("**************************************   **************************************", result);

        try
        {
            testSubject = new Automaton(-1);
            testSubject.setDisplayWidth(DEFAULT_DISPLAY_WIDTH);
            testSubject.propagateNewGeneration();
        } catch (NullPointerException e)
        {
            boolean[] rules = Deencapsulation.getField(testSubject, "rules");
            if (rules == null)
            {
                e.printStackTrace();
                Assert.fail(e.getLocalizedMessage()
                        + "\nYour group should have allocated a rules array in the constructor like this:\n"
                        + "rules = new boolean[8];");
            }
            int length = rules.length;
            if (length != 8)
            {
                if (length == 32)
                {
                    JOptionPane.showMessageDialog(null, "Student is attempting to do Option B1, which is great!");
                } else
                {
                    Assert.fail(e.getLocalizedMessage()
                            + "\nYour group should have allocated a rules array in the constructor "
                            + "(with a length of 8 or 32) something like this:\n" + "rules = new boolean[8];");
                }
            }
        }
//		result = testSubject.toStringCurrentGen();
//		Assert.assertEquals("                                                                               ", result);

        testSubject = new Automaton(255);
        testSubject.setDisplayWidth(DEFAULT_DISPLAY_WIDTH);
        testSubject.propagateNewGeneration();
        result = testSubject.toStringCurrentGen();
        Assert.assertEquals("*******************************************************************************", result);

        testSubject = new Automaton(255);
        testSubject.setDisplayWidth(DEFAULT_DISPLAY_WIDTH);
        testSubject.propagateNewGeneration();
        result = testSubject.toStringCurrentGen();
        Assert.assertEquals("*******************************************************************************", result);

        testSubject = new Automaton(255);
        testSubject.setDisplayWidth(DEFAULT_DISPLAY_WIDTH);
        testSubject.propagateNewGeneration();
        result = testSubject.toStringCurrentGen();
        Assert.assertEquals("*******************************************************************************", result);

        testSubject = new Automaton(1);
        testSubject.setDisplayWidth(DEFAULT_DISPLAY_WIDTH);
        testSubject.propagateNewGeneration();
        result = testSubject.toStringCurrentGen();
        Assert.assertEquals("**************************************   **************************************", result);

        testSubject = new Automaton(126);
        boolean[] rules = Deencapsulation.getField(testSubject, "rules");
        if (rules == null)
        {
            Assert.fail("\nYour group should have allocated a rules array in the constructor like this:\n"
                    + "rules = new boolean[8];");
        }
        int length = rules.length;
        if (length != 8)
        {
            if (length == 32)
            {
                JOptionPane.showMessageDialog(null, "Student is attempting to do Option B1, which is great!");
            } else
            {
                Assert.fail("\nYour group should have allocated a rules array in the constructor "
                        + "(with a length of 8 or 32) something like this:\n" + "rules = new boolean[8];");
            }
        }
        testSubject.setDisplayWidth(DEFAULT_DISPLAY_WIDTH);
        testSubject.propagateNewGeneration();
        result = testSubject.toStringCurrentGen();
        Assert.assertEquals("                                      ***                                      ", result);

        testSubject = new Automaton(4);
        testSubject.setDisplayWidth(DEFAULT_DISPLAY_WIDTH);
        testSubject.propagateNewGeneration();
        result = testSubject.toStringCurrentGen();
        Assert.assertEquals("                                       *                                       ", result);

        testSubject = new Automaton(30);
        testSubject.setDisplayWidth(DEFAULT_DISPLAY_WIDTH);
        testSubject.propagateNewGeneration();
        result = testSubject.toStringCurrentGen();
        Assert.assertEquals("                                      ***                                      ", result);

        testSubject = new Automaton(2000);
        testSubject.setDisplayWidth(DEFAULT_DISPLAY_WIDTH);
        testSubject.propagateNewGeneration();
        result = testSubject.toStringCurrentGen();
        Assert.assertEquals("                                                                               ", result);

        testSubject = new Automaton(129);
        testSubject.setDisplayWidth(DEFAULT_DISPLAY_WIDTH);
        testSubject.propagateNewGeneration();
        result = testSubject.toStringCurrentGen();
        Assert.assertEquals("**************************************   **************************************", result);

        testSubject = new Automaton(255);
        testSubject.setDisplayWidth(DEFAULT_DISPLAY_WIDTH);
        testSubject.propagateNewGeneration();
        result = testSubject.toStringCurrentGen();
        Assert.assertEquals("*******************************************************************************", result);

        testSubject = new Automaton(256);
        testSubject.setDisplayWidth(DEFAULT_DISPLAY_WIDTH);
        testSubject.propagateNewGeneration();
        result = testSubject.toStringCurrentGen();
        Assert.assertEquals("                                                                               ", result);
    }
}