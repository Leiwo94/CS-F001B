
import static org.junit.Assert.fail;

import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.InputStream;
import java.io.PrintStream;
import java.util.Scanner;
import java.util.logging.Logger;

//import javax.annotation.Generated;

import org.junit.*;

//@Generated(value = "org.junit-tools-1.0.6")
public class IntegrationTests {

//	@Generated(value = "org.junit-tools-1.0.6")
	private Logger logger = Logger.getLogger(IntegrationTests.class.toString());
	private final ByteArrayOutputStream outContent = new ByteArrayOutputStream();
	private final ByteArrayOutputStream errContent = new ByteArrayOutputStream();
	private final PrintStream out = System.out;
	private final PrintStream err = System.err;
	private static final int DEFAULT_DISPLAY_WIDTH = 79;
	private static final String lineSeparator = System.lineSeparator();

	@Before
	public void setUp() throws Exception {
		System.setOut(new PrintStream(outContent));
		System.setErr(new PrintStream(errContent));
	}

	@BeforeClass
	public static void setUpBeforeClass() throws Exception {

	}

	@After
	public void tearDown() throws Exception {
		System.setOut(out);
		System.setErr(err);
	}

	@AfterClass
	public static void tearDownAfterClass() throws Exception {

	}

	@Test
	public void testFullIntegration() {
		String data = "1" + lineSeparator + "126" + lineSeparator + "4" + lineSeparator + "30" + lineSeparator + "2000"
				+ lineSeparator + "-1" + lineSeparator + "129" + lineSeparator + "";
		InputStream stdin = System.in;
		try {
			System.setIn(new ByteArrayInputStream(data.getBytes()));
			int rule, k;
			String strUserIn;

			Scanner inputStream = new Scanner(System.in);
			Automaton aut;

			// get rule from user
			do {
				System.out.print("Enter Rule (0 - 255): ");
				// get the answer in the form of a string:
				strUserIn = inputStream.nextLine();
				// and convert it to a number so we can compute:
				rule = Integer.parseInt(strUserIn);

			} while (rule < 0 || rule > 255);

			// create automaton with this rule and single central dot
			aut = new Automaton(rule);
			if (aut.displayWidth != DEFAULT_DISPLAY_WIDTH) {
				fail("Students forgot to set a default displayWidth");
				aut.setDisplayWidth(DEFAULT_DISPLAY_WIDTH);
			}

			// now show it
			System.out.println("   start");
			for (k = 0; k < 100; k++) {
				System.out.println(aut.toStringCurrentGen());
				aut.propagateNewGeneration();
			}
			System.out.println("   end");
			inputStream.close();
		} finally {
			System.setIn(stdin);
			Assert.assertEquals("Enter Rule (0 - 255):    start" + lineSeparator
					+ "                                       *                                       " + lineSeparator
					+ "**************************************   **************************************" + lineSeparator
					+ "                                       *                                       " + lineSeparator
					+ "**************************************   **************************************" + lineSeparator
					+ "                                       *                                       " + lineSeparator
					+ "**************************************   **************************************" + lineSeparator
					+ "                                       *                                       " + lineSeparator
					+ "**************************************   **************************************" + lineSeparator
					+ "                                       *                                       " + lineSeparator
					+ "**************************************   **************************************" + lineSeparator
					+ "                                       *                                       " + lineSeparator
					+ "**************************************   **************************************" + lineSeparator
					+ "                                       *                                       " + lineSeparator
					+ "**************************************   **************************************" + lineSeparator
					+ "                                       *                                       " + lineSeparator
					+ "**************************************   **************************************" + lineSeparator
					+ "                                       *                                       " + lineSeparator
					+ "**************************************   **************************************" + lineSeparator
					+ "                                       *                                       " + lineSeparator
					+ "**************************************   **************************************" + lineSeparator
					+ "                                       *                                       " + lineSeparator
					+ "**************************************   **************************************" + lineSeparator
					+ "                                       *                                       " + lineSeparator
					+ "**************************************   **************************************" + lineSeparator
					+ "                                       *                                       " + lineSeparator
					+ "**************************************   **************************************" + lineSeparator
					+ "                                       *                                       " + lineSeparator
					+ "**************************************   **************************************" + lineSeparator
					+ "                                       *                                       " + lineSeparator
					+ "**************************************   **************************************" + lineSeparator
					+ "                                       *                                       " + lineSeparator
					+ "**************************************   **************************************" + lineSeparator
					+ "                                       *                                       " + lineSeparator
					+ "**************************************   **************************************" + lineSeparator
					+ "                                       *                                       " + lineSeparator
					+ "**************************************   **************************************" + lineSeparator
					+ "                                       *                                       " + lineSeparator
					+ "**************************************   **************************************" + lineSeparator
					+ "                                       *                                       " + lineSeparator
					+ "**************************************   **************************************" + lineSeparator
					+ "                                       *                                       " + lineSeparator
					+ "**************************************   **************************************" + lineSeparator
					+ "                                       *                                       " + lineSeparator
					+ "**************************************   **************************************" + lineSeparator
					+ "                                       *                                       " + lineSeparator
					+ "**************************************   **************************************" + lineSeparator
					+ "                                       *                                       " + lineSeparator
					+ "**************************************   **************************************" + lineSeparator
					+ "                                       *                                       " + lineSeparator
					+ "**************************************   **************************************" + lineSeparator
					+ "                                       *                                       " + lineSeparator
					+ "**************************************   **************************************" + lineSeparator
					+ "                                       *                                       " + lineSeparator
					+ "**************************************   **************************************" + lineSeparator
					+ "                                       *                                       " + lineSeparator
					+ "**************************************   **************************************" + lineSeparator
					+ "                                       *                                       " + lineSeparator
					+ "**************************************   **************************************" + lineSeparator
					+ "                                       *                                       " + lineSeparator
					+ "**************************************   **************************************" + lineSeparator
					+ "                                       *                                       " + lineSeparator
					+ "**************************************   **************************************" + lineSeparator
					+ "                                       *                                       " + lineSeparator
					+ "**************************************   **************************************" + lineSeparator
					+ "                                       *                                       " + lineSeparator
					+ "**************************************   **************************************" + lineSeparator
					+ "                                       *                                       " + lineSeparator
					+ "**************************************   **************************************" + lineSeparator
					+ "                                       *                                       " + lineSeparator
					+ "**************************************   **************************************" + lineSeparator
					+ "                                       *                                       " + lineSeparator
					+ "**************************************   **************************************" + lineSeparator
					+ "                                       *                                       " + lineSeparator
					+ "**************************************   **************************************" + lineSeparator
					+ "                                       *                                       " + lineSeparator
					+ "**************************************   **************************************" + lineSeparator
					+ "                                       *                                       " + lineSeparator
					+ "**************************************   **************************************" + lineSeparator
					+ "                                       *                                       " + lineSeparator
					+ "**************************************   **************************************" + lineSeparator
					+ "                                       *                                       " + lineSeparator
					+ "**************************************   **************************************" + lineSeparator
					+ "                                       *                                       " + lineSeparator
					+ "**************************************   **************************************" + lineSeparator
					+ "                                       *                                       " + lineSeparator
					+ "**************************************   **************************************" + lineSeparator
					+ "                                       *                                       " + lineSeparator
					+ "**************************************   **************************************" + lineSeparator
					+ "                                       *                                       " + lineSeparator
					+ "**************************************   **************************************" + lineSeparator
					+ "                                       *                                       " + lineSeparator
					+ "**************************************   **************************************" + lineSeparator
					+ "                                       *                                       " + lineSeparator
					+ "**************************************   **************************************" + lineSeparator
					+ "                                       *                                       " + lineSeparator
					+ "**************************************   **************************************" + lineSeparator
					+ "                                       *                                       " + lineSeparator
					+ "**************************************   **************************************" + lineSeparator
					+ "                                       *                                       " + lineSeparator
					+ "**************************************   **************************************" + lineSeparator
					+ "   end" + lineSeparator + "", outContent.toString());
		}
	}
}
