import java.util.LinkedList;

public class Foothill
{
   // public data
   public static final int LIST_SIZE = 7;

   public static void main(String[] args)
   {

      // New Linked List
      LinkedList<Card> list = new LinkedList<Card>();

      // Generate 7 random cards
      for (int randCards = 0; randCards < LIST_SIZE; randCards++)
      {
         Card tempCard = generateRandomCard();

         // Dublicate cards
         insert(list, tempCard);
         insert(list, tempCard);
      }

      // Print list immediately
      System.out.println("The List:");
      for (int randCards = 0; randCards < list.size(); randCards++)
      {
         System.out.println(list.get(randCards).toString());
      }

      System.out.println();

      Card card1 = list.get(0);
      Card card2 = list.get(7);

      System.out.println("Remove: " + card1.toString() + ":");
      boolean x = true;
      while (x)
      {
         x = remove(list, card1);
      }
      
      x = true;
      System.out.println("Remove: " + card2.toString() + ":");
      while (x)
      {
         x = remove(list, card2);
      }

      System.out.println("After removing cards: ");
      for (int cards = 0; cards < list.size(); cards++)
      {
         System.out.println(list.get(cards).toString());
      }

      System.out.println("Testing removeAll's return value for card1: "
            + removeAll(list, card1));
      System.out.println("Testing removeAll's return value for card2: "
            + removeAll(list, card2));
   }

   // "global" static Foothill methods
   static Card generateRandomCard()
   {
      // if firstTime = true, use clock to seed, else fixed seed for debugging
      Card.Suit suit;
      char val;

      int suitSelector, valSelector;

      // get random suit and value
      suitSelector = (int) (Math.random() * 4);
      valSelector = (int) (Math.random() * 13);

      // pick suit
      suit = turnIntIntoSuit(suitSelector);
      val = turnIntIntoVal(valSelector);

      return new Card(val, suit);
   }

   // note: this method not needed if we use int for suits instead of enum
   static Card.Suit turnIntIntoSuit(int k)
   {
      return Card.Suit.values()[k]; //
   }

   static char turnIntIntoVal(int k)
   {
      String legalVals = "23456789TJQKA";

      if (k < 0 | k >= legalVals.length())
         return '?';
      return legalVals.charAt(k);
   }

   static boolean insert(LinkedList<Card> my_List, Card x)
   {
      int card;

      if (x == null)
         return false;

      for (card = 0; card < my_List.size(); card++)
      {
         if (x.compareTo(my_List.get(card)) < 0)
         {
            break;
         }
      }

      if (card == my_List.size())
      {
         my_List.add(x);
      } else
         my_List.add(card, x);

      return true;
   }

   static boolean remove(LinkedList<Card> my_List, Card x)
   {
      if (x == null)
         return false;

      for (int card = 0; card < my_List.size(); card++)
      {
         if (x.compareTo(my_List.get(card)) == 0)
         {
            my_List.remove(card);
            return true;
         }
      }

      return false;
   }

   static boolean removeAll(LinkedList<Card> my_List, Card x)
   {
      if (x == null)
         return false;
      boolean card = false;

      for (int listCards = 0; !my_List.isEmpty()
            && listCards < my_List.size(); listCards++)
      {
         if (my_List.get(listCards).compareTo(x) == 0)
         {
            card = true;
            my_List.remove(listCards);
            listCards--;
         }
      }
      return card;
   }
}

// Card Class
class Card
{ // card suit enums
   static final Suit DEFAULT_SUIT = Suit.spades;
   static final char DEFAULT_CARD = 'A';

   public enum Suit
   {
      clubs, diamonds, hearts, spades
   }

   // private data
   private char value;
   private Suit suit;

   // error flag
   private boolean errorFlag;

   // 4 overloaded constructors
   public Card(char value, Suit suit)
   {
      set(value, suit);
   }

   public Card(char value)
   {
      this(value, DEFAULT_SUIT);
   }

   public Card()
   {
      this(DEFAULT_CARD, DEFAULT_SUIT);
   }

   // copy constructor
   public Card(Card card)
   {
      this.suit = card.suit;
      this.value = card.value;
   }

   // mutator
   public boolean set(char value, Suit suit)
   {

      char upVal;

      // convert to uppercase
      upVal = Character.toUpperCase(value);

      if (!isValid(upVal, suit))
      {
         errorFlag = true;
         this.value = upVal;
         this.suit = suit;
         return false;
      }

      else
      {
         errorFlag = false;
         this.value = upVal;
         this.suit = suit;
         return true;

      }
   }

   // accessors
   public char getValue()
   {
      return value;
   }

   public Suit getSuit()
   {
      return suit;
   }

   public boolean isErrorFlag()
   {
      return errorFlag;
   }

   public boolean equals(Card card)
   {
      if (this.value != card.getValue())
         return false;
      if (this.suit != card.getSuit())
         return false;
      if (this.errorFlag != card.isErrorFlag())
         return false;
      return true;
   }

   // Stringizer
   public String toString()
   {
      String cardVal;
      if (errorFlag)
         return "[ Invalid ]";
      else
         cardVal = String.valueOf(value) + " of " + suit;
      return cardVal;
   }

   // Creating isValid helper
   private static boolean isValid(char value, Suit suit)
   {
      char upVal;

      // upVal needs to be initialized again. It does not
      // carry over from public boolean set(char value, Suit suit)
      upVal = Character.toUpperCase(value);

      // validity parameters (learned from Suits as enums)
      if (upVal == 'A' || upVal == 'K' || upVal == 'Q' || upVal == 'J'
            || upVal == 'T' || (upVal >= '2' && upVal <= '9'))
         return true;
      else
         return false;
   }

   // for sort
   protected static char[] valueRanks =
   { '2', '3', '4', '5', '6', '7', '8', '9', 'T', 'J', 'Q', 'K', 'A' };
   protected static Suit[] suitRanks =
   { Suit.clubs, Suit.diamonds, Suit.hearts, Suit.spades };
   protected static final int NUM_VALS = 13;

   // sort member methods
   public int compareTo(Card other)
   {
      if (this.value == other.value)
         return (getSuitRank(this.suit) - getSuitRank(other.suit));

      return (getValueRank(this.value) - getValueRank(other.value));
   }

   public static int getSuitRank(Suit st)
   {
      int k;

      for (k = 0; k < 4; k++)
         if (suitRanks[k] == st)
            return k;

      // should not happen
      return 0;
   }

   public static int getValueRank(char val)
   {
      int k;

      for (k = 0; k < NUM_VALS; k++)
         if (valueRanks[k] == val)
            return k;

      // should not happen
      return 0;
   }

}
