import java.io.*;

public class Foothill
{
   // ------- main --------------
   public static void main(String[] args) throws Exception
   {
      String fileName = write();
      System.gc();

      read(fileName);
   }

   /**
    * @return File name of the data file.
    */
   private static String write()
   {
      EnhancedComputer workComputer = new EnhancedComputer();
      workComputer.setName("Work Computer");
      workComputer.setSpeed("3.4GHz");
      workComputer.setHdspace("500GB");
      workComputer.setRam("4GB");

      EnhancedComputer homeComputer = ((EnhancedComputer) new EnhancedComputer()
            .setName("Home Computer").setSpeed("4GHz").setHdspace("1TB"))
                  .setRam("16GB");
      EnhancedComputer laptop = ((EnhancedComputer) new EnhancedComputer()
            .setName("Laptop").setSpeed("2.93GHz").setHdspace("250GB"))
                  .setRam("8GB");

      EnhancedComputer[] computers =
      { workComputer, homeComputer, laptop };

      PrintWriter myFileOut;
      String fileName = "computerdata.txt";

      try
      {
         myFileOut = new PrintWriter(new File(fileName));
         myFileOut.write(workComputer.toString() + "\n");
         myFileOut.write(homeComputer.toString() + "\n");
         myFileOut.write(laptop.toString() + "\n");
         myFileOut.close();
      }
      catch (Exception e)
      {
         System.out.println("File unknown. Cannot write file.");
      }

      return fileName;
   }

   /**
    * @param fileName
    */
   
   
   private static void read(String fileName)
   {
      BufferedReader myFileIn;
      try
      {

         myFileIn = new BufferedReader(new FileReader(fileName));
         String str;
         System.out.println("Data from computerdata.txt:");
         while ((str = myFileIn.readLine()) != null)
         {
            System.out.println(str);
         }
         myFileIn.close();
      }
      catch (Exception e)
      {
         System.out.println("Cannot read file");
      }
   }

}


/*
 Run:
Work Computer: Speed:3.4GHz, Hard Drive Space:500GB, RAM:4GB successfully garbage collected
Laptop: Speed:2.93GHz, Hard Drive Space:250GB, RAM:8GB successfully garbage collected
Home Computer: Speed:4GHz, Hard Drive Space:1TB, RAM:16GB successfully garbage collected
Data from computerdata.txt:
Work Computer: Speed:3.4GHz, Hard Drive Space:500GB, RAM:4GB
Home Computer: Speed:4GHz, Hard Drive Space:1TB, RAM:16GB
Laptop: Speed:2.93GHz, Hard Drive Space:250GB, RAM:8GB
*/