/**
 * @author TODO: Kalei Woods
 *
 */
public class Computer
{
    private String name;
    protected String speed;
    protected String hdspace;

    @SuppressWarnings("unchecked")
    public Computer()
    {
    }

    @Override
    /*
     * Overriding finalize method to check which object is garbage collected
     */
    protected void finalize() throws Throwable
    {
        System.out.println(this.toString() + " successfully garbage collected");
    }

    /**
     * @return the name
     */
    public String getName()
    {
        return name;
    }

    /**
     * @param name the name to set
     */
    public Computer setName(String name)
    {
        this.name = name;
        return this;
    }

    /**
     * @return the speed
     */
    public String getSpeed()
    {
        return speed;
    }

    /**
     * @param speed the speed to set
     */
    public Computer setSpeed(String speed)
    {
        this.speed = speed;
        return this;
    }

    /**
     * @return the hdspace
     */
    public String getHdspace()
    {
        return hdspace;
    }

    /**
     * @param hdspace the hdspace to set
     */
    public Computer setHdspace(String hdspace)
    {
        this.hdspace = hdspace;
        return this;
    }

}
