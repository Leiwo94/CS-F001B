/**
 * @author TODO: Kalei Woods
 *
 */
public class EnhancedComputer extends Computer
{

    private String ram;

    /**
     * 
     */
    public EnhancedComputer()
    {
    }

    /**
     * @return the ram
     */
    public String getRam()
    {
        return ram;
    }

    /**
     * @param ram the ram to set
     */
    public EnhancedComputer setRam(String ram)
    {
        this.ram = ram;
        return this;
    }

    /**
     * @return the price
     */
    public double getPrice()
    {
        double thePrice = 500;
    
        if (this.speed == "4GHz")
        {
            thePrice += 300;
        } else
        {
            thePrice += 100;
        }
    
        if (this.hdspace == "1TB")
        {
            thePrice += 150;
        } else
        {
            thePrice += 80;
        }
    
        if (this.ram == "16GB")
        {
            thePrice += 200;
        } else
        {
            thePrice += 100;
        }
    
        return thePrice;
    }

    @Override
    public String toString()
    {
        return getName() + ":" + " Speed:" + getSpeed() + ", Hard Drive Space:" + getHdspace() + ", RAM:" + getRam();
    }

}
